import sys

from features import *

if __name__ == '__main__':
	infile = open(sys.argv[1], 'r')
	contents = infile.read()[1:].split('\n>')
	infile.close()
	identifiers = []
	for ele in contents:
		ele_list = ele.split('\n')
		identifiers.append(ele_list[0].split()[0])

	for identifier in identifiers:
		features(identifier, 'test')

		infile_res_num = open('../test_features/'+identifier+'.res_num', 'r')
		infile_flags = open('../test_features/'+identifier+'.flags', 'r')
		infile_even_odd_comp = open('../test_features/'+identifier+'.even_odd_comp', 'r')
		infile_SSE_num = open('../test_features/'+identifier+'.SSE_num', 'r')
		infile_coevo_info = open('../test_features/'+identifier+'.coevo_info', 'r')
		infile_intervening_len = open('../test_features/'+identifier+'.intervening_len', 'r')
		outfile = open('../test_features/'+identifier+'_features', 'w')
		outfile_obj = open('../test_features/'+identifier+'_features_obj', 'w')

		while True:
			line1 = infile_res_num.readline()
			if not line1:
				break

			line1 = line1.strip('\n')
			pos1 = line1.index(' ')
			SSE1, line1 = line1[:pos1], line1[(pos1+1):]
			pos2 = line1.index(' ')
			SSE2, feature_values1 = line1[:pos2], line1[(pos2+1):]
			pos = pos1+pos2+2

			line2 = infile_flags.readline().strip('\n')
			line3 = infile_even_odd_comp.readline().strip('\n')
			line4 = infile_SSE_num.readline().strip('\n')
			line5 = infile_coevo_info.readline().strip('\n')
			line6 = infile_intervening_len.readline().strip('\n')

			feature_values2 = line2[pos:]
			feature_values3 = line3[pos:]
			feature_values4 = line4[pos:]
			feature_values5 = line5[pos:]
			feature_values6 = line6[pos:]

			outfile.write(feature_values1+feature_values2+feature_values3+feature_values4+feature_values5+feature_values6+'\n')
			outfile_obj.write(SSE1+' '+SSE2+'\n')

		infile_res_num.close()
		infile_flags.close()
		infile_even_odd_comp.close()
		infile_SSE_num.close()
		infile_coevo_info.close()
		infile_intervening_len.close()
		outfile.close()
		outfile_obj.close()
