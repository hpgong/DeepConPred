totnum = size(Dtrain, 1);
data = Dtrain(:, 1:end-1);
labels = Dtrain(:, end);
targets = zeros(totnum, 3);
classsize = zeros(1, 3);
for i = 1:totnum
	if labels(i) == 1
		targets(i,1) = 1;
		classsize(1) = classsize(1)+1;
	elseif labels(i) == 0
		targets(i,2) = 1;
		classsize(2) = classsize(2)+1;
	else
		targets(i,3) = 1;
		classsize(3) = classsize(3)+1;
	end
end

rand('state',0); %so we know the permutation of the training data
randomorder=randperm(totnum);

numbatches = totnum/batchsize;
numdims = size(data,2);
batchdata = zeros(totnum, numdims);
batchtargets = zeros(totnum, 3);

for i=1:totnum
	batchdata(i, :) = data(randomorder(i), :);
	batchtargets(i, :) = targets(randomorder(i), :);
end
clear data labels targets randomorder

%%% Reset random seeds 
rand('state',sum(100*clock));
randn('state',sum(100*clock));
