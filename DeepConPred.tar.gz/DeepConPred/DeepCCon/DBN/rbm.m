epsilonw      = 0.01;   % Learning rate for weights
epsilonvb     = 0.1;   % Learning rate for biases of visible units
epsilonhb     = 0.1;   % Learning rate for biases of hidden units
weightcost  = 0.0002;
initialmomentum  = 0.5;
finalmomentum    = 0.9;

% Initializing symmetric weights and biases.
vishidW = unifrnd(-sqrt(6/(numvis+numhid)), sqrt(6/(numvis+numhid)), numvis, numhid);
hidB  = zeros(1, numhid);
visB  = zeros(1, numvis);

vishidWinc  = zeros(numvis, numhid);
hidBinc = zeros(1, numhid);
visBinc = zeros(1, numvis);
batchposhidprobs = zeros(totnum, numhid);

for epoch = 1:RBMmaxepoch
	fprintf(logoutfile, '.');
	for batch = 1:numbatches

		%%%%%%%%% START POSITIVE PHASE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		data = batchdata(((batch-1)*batchsize+1):(batch*batchsize), :);
		poshidprobs = 1./(1 + exp(-data*vishidW - repmat(hidB,batchsize,1)));
		batchposhidprobs(((batch-1)*batchsize+1):(batch*batchsize), :)=poshidprobs;
		posprods    = data' * poshidprobs;
		poshidact   = sum(poshidprobs);
		posvisact = sum(data);

		%%%%%%%%% END OF POSITIVE PHASE  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		poshidstates = poshidprobs > rand(batchsize,numhid);

		%%%%%%%%% START NEGATIVE PHASE  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		negdata = 1./(1 + exp(-poshidstates*vishidW' - repmat(visB,batchsize,1)));
		neghidprobs = 1./(1 + exp(-negdata*vishidW - repmat(hidB,batchsize,1)));
		negprods  = negdata'*neghidprobs;
		neghidact = sum(neghidprobs);
		negvisact = sum(negdata); 

		%%%%%%%%% END OF NEGATIVE PHASE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

		if epoch > 5
			momentum=finalmomentum;
		else
			momentum=initialmomentum;
		end

		%%%%%%%%% UPDATE WEIGHTS AND BIASES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		vishidWinc = momentum*vishidWinc + epsilonw*((posprods-negprods)/batchsize - weightcost*vishidW);
		visBinc = momentum*visBinc + (epsilonvb/batchsize)*(posvisact-negvisact);
		hidBinc = momentum*hidBinc + (epsilonhb/batchsize)*(poshidact-neghidact);

		vishidW = vishidW + vishidWinc;
		visB = visB + visBinc;
		hidB = hidB + hidBinc;

		%%%%%%%%%%%%%%%% END OF UPDATES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	end
end
