import sys
import string
import random
import numpy as np

if __name__ == '__main__':
	w = 9

	infile = open(sys.argv[1], 'r')
	contents = infile.read()[1:].split('\n>')
	infile.close()
	identifiers = []
	for ele in contents:
		ele_list = ele.split('\n')
		identifiers.append(ele_list[0].split()[0])

	for identifier in identifiers:
		infile = open('../test_data/'+identifier+'.DeepRCon', 'r')
		contents = infile.readlines()
		infile.close()
		prot = contents[1].strip('\n')
		N = len(prot)
		contents = contents[4:]
		a1 = np.zeros((N, N))
		for line in contents:
			line_list = line.split()
			id1 = string.atoi(line_list[0][1:])
			id2 = string.atoi(line_list[1][1:])
			a1[id1-1, id2-1] = string.atof(line_list[2])
			a1[id2-1, id1-1] = a1[id1-1, id2-1]

		a2 = np.loadtxt('../test_data/'+identifier+'.CCMpred')
		a2 = (a2+a2.T)/2.0

		infile = open('../test_data/'+identifier+'.MSA', 'r')
		contents = infile.readlines()
		infile.close()
		a3 = len(contents)

		outfile = open('../test_features/'+identifier+'_features', 'w')
		outfile_obj = open('../test_features/'+identifier+'_features_obj', 'w')
		for id1 in range(N-25):
			for id2 in range(id1+25, N):
				for i in range(id1-(w-1)/2, id1+(w-1)/2+1):
					for j in range(id2-(w-1)/2, id2+(w-1)/2+1):
						if (i < 0) or (i >= N):
							outfile.write('0.0 ')
						elif (j < 0) or (j >= N):
							outfile.write('0.0 ')
						else:
							outfile.write('%.10f ' % a1[i, j])
				for i in range(id1-(w-1)/2, id1+(w-1)/2+1):
					for j in range(id2-(w-1)/2, id2+(w-1)/2+1):
						if (i < 0) or (i >= N):
							outfile.write('0.0 ')
						elif (j < 0) or (j >= N):
							outfile.write('0.0 ')
						else:
							outfile.write('%.10f ' % a2[i, j])
				outfile.write('%d\n' % a3)
				outfile_obj.write(prot[id1]+str(id1+1)+' '+prot[id2]+str(id2+1)+'\n')

		outfile.close()
		outfile_obj.close()
