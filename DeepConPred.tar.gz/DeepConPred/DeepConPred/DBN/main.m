clear all
close all

hidnode1 = 300;
hidnode2 = 200;
hidnode3 = 150;
train_features_path = '../train_features/train_features';
test_fasta_path = '../../test_examples.fa';

dbn(hidnode1, hidnode2, hidnode3, train_features_path, test_fasta_path);

quit;
