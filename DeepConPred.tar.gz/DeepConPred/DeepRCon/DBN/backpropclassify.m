BPmaxepoch = 100;

fprintf(logoutfile, '\nTraining discriminative model by minimizing cross entropy error');

load('./model_pars/VisHid1CVRBMPar.mat');
load('./model_pars/Hid1Hid2CVRBMPar.mat');
load('./model_pars/Hid2Hid3CVRBMPar.mat');

makebatches;

%%%% PREINITIALIZE WEIGHTS OF THE DISCRIMINATIVE MODEL%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
w1 = [vishid1W; hid1recB];
w2 = [hid1hid2W; hid2recB];
w3 = [hid2hid3W; hid3recB];
w_class = unifrnd(-sqrt(6/(size(w3,2)+2)), sqrt(6/(size(w3,2)+2)), size(w3,2)+1, 2);

save('./model_pars/InitW_classPar.mat', 'w_class');

clear vishid1W hid1recB visgenB
clear hid1hid2W hid2recB hid1genB
clear hid2hid3W hid3recB hid2genB
%%%%%%%%%% END OF PREINITIALIZATIO OF WEIGHTS  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

l1 = size(w1,1)-1;
l2 = size(w2,1)-1;
l3 = size(w3,1)-1;
l4 = size(w_class,1)-1;
l5 = 2;

num_identifiers = 1;
infile = fopen(test_fasta_path, 'r');
while ~feof(infile)
	file_line = fgetl(infile);
	if strcmp(file_line(1), '>')
		space_loc = strfind(file_line, ' ');
		if ~isempty(space_loc)
  			allidentifiers{num_identifiers} = file_line(2:space_loc(1)-1);
  		else
  			allidentifiers{num_identifiers} = file_line(2:end);
		end
  		num_identifiers = num_identifiers+1;
	end
end
fclose(infile);

for epoch = 1:BPmaxepoch
	fprintf(logoutfile, '.');
	%%%%%%%%%%%%%%% BEGIN OF CONJUGATE GRADIENT WITH 3 LINESEARCHES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
	for batch = 1:numbatches

		data = batchdata(((batch-1)*batchsize+1):(batch*batchsize), :);
		targets = batchtargets(((batch-1)*batchsize+1):(batch*batchsize), :);

		%%%%%%%%%%%%%%% PERFORM CONJUGATE GRADIENT WITH 3 LINESEARCHES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		max_iter = 3;

		if epoch < 6  % First update top-level weights holding other weights fixed. 
			XX = [data ones(batchsize,1)];
			w1probs = 1./(1 + exp(-XX*w1)); w1probs = [w1probs  ones(batchsize,1)];
			w2probs = 1./(1 + exp(-w1probs*w2)); w2probs = [w2probs ones(batchsize,1)];
			w3probs = 1./(1 + exp(-w2probs*w3));

			VV = [w_class(:)']';
			Dim = [l4; l5];
			[X, fX] = minimize(VV,'CG_CLASSIFY_INIT',max_iter,Dim,w3probs,targets);
			w_class = reshape(X,l4+1,l5);
		else
			VV = [w1(:)' w2(:)' w3(:)' w_class(:)']';
			Dim = [l1; l2; l3; l4; l5];
			[X, fX] = minimize(VV,'CG_CLASSIFY',max_iter,Dim,data,targets);

			w1 = reshape(X(1:(l1+1)*l2),l1+1,l2);
			xxx = (l1+1)*l2;
			w2 = reshape(X(xxx+1:xxx+(l2+1)*l3),l2+1,l3);
			xxx = xxx+(l2+1)*l3;
			w3 = reshape(X(xxx+1:xxx+(l3+1)*l4),l3+1,l4);
			xxx = xxx+(l3+1)*l4;
			w_class = reshape(X(xxx+1:xxx+(l4+1)*l5),l4+1,l5);
		end
	end
	%%%%%%%%%%%%%%% END OF CONJUGATE GRADIENT WITH 3 LINESEARCHES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	%%%%%%%%%%%%%%%%%%%% COMPUTE TEST RESULTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	if ~exist(['../test_results/epoch' num2str(epoch)])
		mkdir(['../test_results/epoch' num2str(epoch)]);
	end
	for i = 1:num_identifiers-1
		identifier = allidentifiers{i};

		resultoutfile = fopen(['../test_results/epoch' num2str(epoch) '/' identifier '_epoch' num2str(epoch) '.DeepRCon'], 'w');

		Dtest = load(['../test_features/' identifier '_features']);
		for c = 131:650
			Dtest(:,c) = 1.0*(Dtest(:,c)-min_val1)/(max_val1-min_val1);
		end
		for c = 693:752
			Dtest(:,c) = 1.0*(Dtest(:,c)-min_val2(c-692))/(max_val2(c-692)-min_val2(c-692));
		end

		infile_SS = fopen(['../test_data/' identifier '.SS'], 'r');
		file_line = fgetl(infile_SS);
		fprintf(resultoutfile, '%s\n', file_line);
		file_line = fgetl(infile_SS);
		fprintf(resultoutfile, '%s\n', file_line);
		fclose(infile_SS);

		fprintf(resultoutfile, '\n#res1 res2      contact_prob      no-contact_prob\n');

		infile_obj = fopen(['../test_features/' identifier '_features_obj']);
		C = textscan(infile_obj, '%s %s');
		fclose(infile_obj);

		N = size(Dtest, 1);

		Dtest = [Dtest ones(N,1)];
		w1probs = 1./(1 + exp(-Dtest*w1)); w1probs = [w1probs  ones(N,1)];
		w2probs = 1./(1 + exp(-w1probs*w2)); w2probs = [w2probs ones(N,1)];
		w3probs = 1./(1 + exp(-w2probs*w3)); w3probs = [w3probs  ones(N,1)];
		targetsout = exp(w3probs*w_class);
		targetsout = targetsout./repmat(sum(targetsout,2),1,2);

		for j = 1:size(targetsout, 1)
			fprintf(resultoutfile, '%s %s      %f      %f\n', C{1}{j}, C{2}{j}, targetsout(j, 1), targetsout(j, 2));
		end

		fclose(resultoutfile);
	end
	%%%%%%%%%%%%%% END OF COMPUTING TEST RESULTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	save(['./model_pars/BPEpoch' num2str(epoch) 'Par.mat'], 'w1', 'w2', 'w3', 'w_class');
end

fprintf(logoutfile, 'Backpropclassify completed.\n');
