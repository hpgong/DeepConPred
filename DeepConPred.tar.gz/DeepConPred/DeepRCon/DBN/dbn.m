function dbn(hidnode1, hidnode2, hidnode3, train_features_path, test_fasta_path)

Dtrain = load(train_features_path);

hidnodes = [hidnode1, hidnode2, hidnode3];
batchsize = 1000;

i = 1;
init_totnum = size(Dtrain, 1);
for j = 1:init_totnum
	if Dtrain(j, end) == 0
		class_ind(i) = j;
		i = i+1;
	end
end

rest_num = mod(init_totnum, batchsize);
rand('state',0); %so we know the permutation of the training data

randomorder = class_ind(randperm((i-1), rest_num));
Dtrain(randomorder, :) = [];
clear class_ind

if ~exist('model_pars', 'dir')
	mkdir('model_pars');
end

logoutfile = fopen('./DeepRCon_dbn_log', 'w');
fprintf(logoutfile, 'hidnodes = [%d, %d, %d]\n', hidnodes(1), hidnodes(2), hidnodes(3));
fprintf(logoutfile, 'Learning rate for weights = 0.01, biases of visible units = 0.1, biases of hidden units = 0.1\n');

max_val1 = max(max(Dtrain(:,131:650)));
min_val1 = min(min(Dtrain(:,131:650)));
for c = 131:650
	Dtrain(:,c) = 1.0*(Dtrain(:,c)-min_val1)/(max_val1-min_val1);
end
max_val2 = max(Dtrain(:,693:752));
min_val2 = min(Dtrain(:,693:752));
for c = 693:752
	Dtrain(:,c) = 1.0*(Dtrain(:,c)-min_val2(c-692))/(max_val2(c-692)-min_val2(c-692));
end
save('./model_pars/max_min_vals', 'max_val1', 'min_val1', 'max_val2', 'min_val2');

makebatches;

fprintf(logoutfile, 'Number of samples in class1 = %d\n', classsize(1));
fprintf(logoutfile, 'Number of samples in class2 = %d\n', classsize(2));
clear classsize

RBMmaxepoch=50;
fprintf(logoutfile, 'Pretraining a deep belief network.\n');

numvis = numdims; numhid = hidnodes(1);
fprintf(logoutfile, 'Pretraining Layer 1 with RBM: %d-%d ', numvis, numhid);
rbm;
vishid1W = vishidW; hid1recB = hidB; visgenB = visB;
save('./model_pars/VisHid1CVRBMPar.mat', 'vishid1W', 'hid1recB', 'visgenB');
fprintf(logoutfile, ' Layer 1 with RBM completed\n');

numvis = hidnodes(1); numhid = hidnodes(2);
fprintf(logoutfile, 'Pretraining Layer 2 with RBM: %d-%d ', numvis, numhid);
batchdata = batchposhidprobs;
rbm;
hid1hid2W = vishidW; hid2recB = hidB; hid1genB = visB;
save('./model_pars/Hid1Hid2CVRBMPar.mat', 'hid1hid2W', 'hid2recB', 'hid1genB')
fprintf(logoutfile, ' Layer 2 with RBM completed\n');

numvis = hidnodes(2); numhid = hidnodes(3);
fprintf(logoutfile,'Pretraining Layer 3 with RBM: %d-%d ', numvis, numhid);
batchdata=batchposhidprobs;
rbm;
hid2hid3W = vishidW; hid3recB = hidB; hid2genB = visB;
save('./model_pars/Hid2Hid3CVRBMPar.mat', 'hid2hid3W', 'hid3recB', 'hid2genB')
fprintf(logoutfile,' Layer 3 with RBM completed\n');

backpropclassify;

fclose(logoutfile);

