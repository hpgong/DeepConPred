import sys
import random

from features import *

if __name__ == '__main__':
	infile = open(sys.argv[1], 'r')
	contents = infile.read()[1:].split('\n>')
	infile.close()
	identifiers = []
	for ele in contents:
		ele_list = ele.split('\n')
		identifiers.append(ele_list[0].split()[0])

	outfile = open('../train_features/train_features_all', 'w')
	for identifier in identifiers:
		features(identifier, 'train')

		infile_true_label = open('../train_data/'+identifier+'.true_contact', 'r')
		contents = infile_true_label.readlines()[4:]
		infile_true_label.close()

		label = {}
		for ele in contents:
			ele_list = ele.split()
			label[ele_list[0]+'_'+ele_list[1]] = ele_list[2]

		infile_res_pairs_SS = open('../train_features/'+identifier+'.res_pairs_SS', 'r')
		infile_res_pairs_ACC = open('../train_features/'+identifier+'.res_pairs_ACC', 'r')
		infile_res_pairs_smoothed_PSSM = open('../train_features/'+identifier+'.res_pairs_smoothed_PSSM', 'r')
		infile_res_pairs_coevo_info = open('../train_features/'+identifier+'.res_pairs_coevo_info', 'r')
		infile_res_pairs_SSCP = open('../train_features/'+identifier+'.res_pairs_SSCP', 'r')
		infile_res_pairs_SSConProb = open('../train_features/'+identifier+'.res_pairs_SSConProb', 'r')
		infile_intervening_seq_SS = open('../train_features/'+identifier+'.intervening_seq_SS', 'r')
		infile_intervening_seq_len = open('../train_features/'+identifier+'.intervening_seq_len', 'r')
		infile_intervening_seq_NV = open('../train_features/'+identifier+'.intervening_seq_NV', 'r')
		infile_entire_prot_ACC = open('../train_features/'+identifier+'.entire_prot_ACC', 'r')
		infile_entire_prot_len = open('../train_features/'+identifier+'.entire_prot_len', 'r')

		while True:
			line1 = infile_res_pairs_SS.readline().rstrip('\n')
			if not line1:
				break

			line2 = infile_res_pairs_ACC.readline().rstrip('\n')
			line3 = infile_res_pairs_smoothed_PSSM.readline().rstrip('\n')
			line4 = infile_res_pairs_coevo_info.readline().rstrip('\n')
			line5 = infile_res_pairs_SSCP.readline().rstrip('\n')
			line6 = infile_res_pairs_SSConProb.readline().rstrip('\n')
			line7 = infile_intervening_seq_SS.readline().rstrip('\n')
			line8 = infile_intervening_seq_len.readline().rstrip('\n')
			line9 = infile_intervening_seq_NV.readline().rstrip('\n')
			line10 = infile_entire_prot_ACC.readline().rstrip('\n')
			line11 = infile_entire_prot_len.readline().rstrip('\n')

			pos1 = line1.index(' ')
			res1 = line1[:pos1]
			line1 = line1[pos1+1:]
			pos2 = line1.index(' ')
			res2 = line1[:pos2]
			feature1 = line1[pos2+1:]


			pos = pos1+pos2+2
			feature2 = line2[pos:]
			feature3 = line3[pos:]
			feature4 = line4[pos:]
			feature5 = line5[pos:]
			feature6 = line6[pos:]
			feature7 = line7[pos:]
			feature8 = line8[pos:]
			feature9 = line9[pos:]
			feature10 = line10[pos:]
			feature11 = line11[pos:]


			outfile.write(feature1+feature2+feature3+feature4+feature5+feature6+feature7+feature8+feature9+feature10+feature11+label[res1+'_'+res2]+'\n')

		infile_res_pairs_SS.close()
		infile_res_pairs_ACC.close()
		infile_res_pairs_smoothed_PSSM.close()
		infile_res_pairs_coevo_info.close()
		infile_res_pairs_SSCP.close()
		infile_res_pairs_SSConProb.close()
		infile_intervening_seq_SS.close()
		infile_intervening_seq_len.close()
		infile_intervening_seq_NV.close()
		infile_entire_prot_ACC.close()
		infile_entire_prot_len.close()
	outfile.close()

	infile = open('../train_features/train_features_all', 'r')
	outfile = open('../train_features/train_features', 'w')
	pos_samples, neg_samples = 0, 0
	neg_indexes = []
	ind = 0
	for line in infile:
		line_list = line.split()
		if line_list[-1] == '1':
			pos_samples += 1
			outfile.write(line)
		else:
			neg_samples += 1
			neg_indexes.append(ind)
		ind += 1

	train_neg_indexes = random.sample(neg_indexes, int((pos_samples+neg_samples)*0.03)-pos_samples)
	train_neg_indexes.sort()

	infile.seek(0)
	ind = 0
	for line in infile:
		if train_neg_indexes:
			if ind == train_neg_indexes[0]:
				outfile.write(line)
				del train_neg_indexes[0]
		else:
			break
		ind += 1
	infile.close()
	outfile.close()
