#!/usr/bin/env python

import sys, os
import string
import numpy as np

def calc_smoothed_PSSM_arr(identifier, prot, w, sw, data_class):
	N = len(prot)
	PSSM_arr = np.zeros((N, 20), dtype=np.int64)
	smoothed_PSSM_arr = np.zeros((N, 20), dtype=np.int64)

	infile_PSSM = open('../'+data_class+'_data/'+identifier+'.PSSM', 'r')
	for i in range(3):
		line = infile_PSSM.readline()
	if line[11:69] != 'A  R  N  D  C  Q  E  G  H  I  L  K  M  F  P  S  T  W  Y  V':
		print 'PSSM file format error'
		sys.exit(1)
	seq = ''
	i = 0
	while True:
		line = infile_PSSM.readline()
		if line == '\n':
			break

		begin_id = 9
		for j in range(20):
			if (line[begin_id] != ' ') and (line[begin_id] != '-'):
				print 'PSSM file format exception'
				sys.exit(1)
			PSSM_arr[i, j] = string.atoi(line[begin_id:begin_id+3])
			begin_id += 3
		i += 1
		seq += line[6]
	if (seq != prot) or (i != N):
		print 'The different protein sequences!\nprotein:\n%s\nPSSM_sequence:\n%s' % (prot, seq)
		print '%d != %d' % (i, N)
		sys.exit(1)
	infile_PSSM.close()

	for i in range(N):
		for j in range(i-(sw-1)/2, i+(sw-1)/2+1):
			if (j >= 0) and (j <= N-1):
				smoothed_PSSM_arr[i, :] += PSSM_arr[j, :]

	return smoothed_PSSM_arr		

def calc_plmDCA_arr(identifier, prot, w, data_class):
	N = len(prot)
	plmDCA_arr = np.zeros((N, N))

	ifp1 = open('../'+data_class+'_data/'+identifier+'.MSA_hmmer_fa', 'r')
	line = ifp1.readline()
	MSA_line = ifp1.readline().strip()
	ifp1.close()
	tmp_line = MSA_line.replace('.', '')
	tmp_line = tmp_line.replace('-', '')
	if N != len(tmp_line):
		print 'The different sequence lengths!  protein: %d  aligned sequence: %d' % (N, len(tmp_line))
		sys.exit(1)
	index_dict = {}
	_NA_list = []
	NA_list = []
	index = 0
	_index = 0
	for C in MSA_line:
		if C.isupper():
			_index += 1
			index += 1
			index_dict[_index] = index
		elif C == '-':
			_index += 1
			_NA_list.append(_index)
		elif C.islower():
			index += 1
			NA_list.append(index)
		elif C == '.':
			pass
		else:
			print 'Unknown char in aligned sequence'
			sys.exit(1)

	ifp2 = open('../'+data_class+'_data/'+identifier+'.plmDCA', 'r')
	for line in ifp2:
		line_list = line.strip().split(',')
		i1 = string.atoi(line_list[0])
		i2 = string.atoi(line_list[1])
		if (i1 not in _NA_list) and (i2 not in _NA_list):
			plmDCA_arr[index_dict[i1]-1, index_dict[i2]-1] = string.atof(line_list[2])
	ifp2.close()

	return plmDCA_arr

def calc_AA_SSCP_arr(prot, w, AA2id, SS2id):
	AA_SSCP_arr = np.zeros((9, 20, 20))
	infile_AA_SSCP = open('../database/AA_SSCP_db', 'r')
	line = infile_AA_SSCP.readline()
	while True:
		line = infile_AA_SSCP.readline()
		if not line:
			break

		if line[:20] == 'Secondary structure:':
			SS_info = line[21:24]
			line = infile_AA_SSCP.readline()
			col_AA = line.split()
			for i in range(20):
				line = infile_AA_SSCP.readline()
				row_AA = line[0]
				if (AA2id[row_AA] != i) or (row_AA != col_AA[i]):
					print 'AA column orders error in SSCP database file'
					sys.exit(1)
				line = line[1:]
				line_list = line.split()
				for j in range(len(line_list)):
					AA_SSCP_arr[SS2id[SS_info], AA2id[row_AA], AA2id[col_AA[j]]] = string.atof(line_list[j])
	infile_AA_SSCP.close()

	return AA_SSCP_arr

def calc_index_info(identifier, prot, data_class):
	index_seqID, index_prob = {}, {}
	infile_result = open('../'+data_class+'_data/'+identifier+'.DeepCCon', 'r')
	contents = infile_result.readlines()[3:]
	infile_result.close()

	if contents[1] != '#No appropriate secondary structure element (SSE) pair exists!\n':
		index = 0
		SSE_info_list = []
		for i in range(len(contents)):
			if contents[i] == '\n':
				break
			SSE_info_list.append(contents[i])
		contents = contents[(i+2):]

		for i in range(len(SSE_info_list)-1):
			for j in range(i+1, len(SSE_info_list)):

				SSE1_info = SSE_info_list[i]
				SSE2_info = SSE_info_list[j]

				seq_ID1 = SSE1_info.split()[1]
				seq_ID1_list = seq_ID1[7:len(seq_ID1)-1].split(',')
				for k in range(len(seq_ID1_list)):
					seq_ID1_list[k] = string.atoi(seq_ID1_list[k])
				seq_ID2 = SSE2_info.split()[1]
				seq_ID2_list = seq_ID2[7:len(seq_ID2)-1].split(',')
				for k in range(len(seq_ID2_list)):
					seq_ID2_list[k] = string.atoi(seq_ID2_list[k])
				pos1 = seq_ID1_list[len(seq_ID1_list)-1]
				pos2 = seq_ID2_list[0]
				sep = pos2-pos1-1
				if sep <= 1:
					continue

				index_seqID[index] = seq_ID1_list+seq_ID2_list
				index += 1

		index = 0
		for line in contents:
			index_prob[index] = line.split()[2:]
			index += 1

	return index_seqID, index_prob

def natural_vector(prot_seq):
	AA_LIST = ['A', 'R', 'N', 'D', 'C', 'E', 'Q', 'G', 'H', 'I', 'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W', 'Y', 'V']
	AA_dict = {}
	for i in range(len(AA_LIST)):
		AA_dict[i] = []
	for i in xrange(len(prot_seq)):
		AA_dict[AA_LIST.index(prot_seq[i])].append(i)

	n_arr = np.zeros((20,), dtype=np.int64)
	u_arr = np.zeros((20,))
	D_arr = np.zeros((20,))

	for i in range(len(AA_LIST)):
		n_arr[i] = len(AA_dict[i])
		if n_arr[i] > 0:
			u_arr[i] = 1.0*sum(np.array(AA_dict[i]))/n_arr[i]
		else:
			u_arr[i] = 0

	n = len(prot_seq)
	for i in range(len(AA_LIST)):
		t = 0
		for j in range(n_arr[i]):
			t += (AA_dict[i][j] - u_arr[i])**2

		if n_arr[i] > 0:
			D_arr[i] = 1.0*t/(n_arr[i]*n)
		else:
			D_arr[i] = 0

	nv = np.zeros((60,))
	for i in range(20):
		nv[3*i] = n_arr[i]
		nv[3*i+1] = u_arr[i]
		nv[3*i+2] = D_arr[i]

	return nv

def features(identifier, data_class):
	w, cw, sw = 13, 3, 5

	AA2id = {'A':0, 'R':1, 'N':2, 'D':3, 'C':4, 'E':5, 'Q':6, 'G':7, 'H':8, 'I':9, 'L':10, 'K':11, 'M':12, 'F':13, 'P':14, 'S':15, 'T':16, 'W':17, 'Y':18, 'V':19}
	SS2id = {'H2H':0, 'H2E':1, 'H2C':2, 'E2H':3, 'E2E':4, 'E2C':5, 'C2H':6, 'C2E':7, 'C2C':8}

	infile_SS = open('../'+data_class+'_data/'+identifier +'.SS', 'r')
	line = infile_SS.readline()
	prot = infile_SS.readline().strip('\n')
	SS_line = infile_SS.readline().strip('\n')
	infile_SS.close()

	infile_ACC = open('../'+data_class+'_data/'+identifier +'.ACC', 'r')
	line = infile_ACC.readline()
	line = infile_ACC.readline()
	ACC_line = infile_ACC.readline().strip()
	infile_ACC.close()

	N = len(prot)

	smoothed_PSSM_arr = calc_smoothed_PSSM_arr(identifier, prot, w, sw, data_class)
	plmDCA_arr = calc_plmDCA_arr(identifier, prot, w, data_class)
	AA_SSCP_arr = calc_AA_SSCP_arr(prot, w, AA2id, SS2id)
	index_seqID, index_prob = calc_index_info(identifier, prot, data_class)

	ACC2id = {'e':0, '-':1}
	ACCNum = np.zeros((2,), dtype=np.int64)
	for ele in ACC_line:
		ACCNum[ACC2id[ele]] += 1
	ACCPct = 1.0*ACCNum/len(ACC_line)

	outfile_res_pairs_SS = open('../'+data_class+'_features/'+identifier+'.res_pairs_SS', 'w')
	outfile_res_pairs_ACC = open('../'+data_class+'_features/'+identifier+'.res_pairs_ACC', 'w')
	outfile_res_pairs_smoothed_PSSM = open('../'+data_class+'_features/'+identifier+'.res_pairs_smoothed_PSSM', 'w')
	outfile_res_pairs_coevo_info = open('../'+data_class+'_features/'+identifier+'.res_pairs_coevo_info', 'w')
	outfile_res_pairs_SSCP = open('../'+data_class+'_features/'+identifier+'.res_pairs_SSCP', 'w')
	outfile_res_pairs_SSConProb = open('../'+data_class+'_features/'+identifier+'.res_pairs_SSConProb', 'w')
	outfile_intervening_seq_SS = open('../'+data_class+'_features/'+identifier+'.intervening_seq_SS', 'w')
	outfile_intervening_seq_len = open('../'+data_class+'_features/'+identifier+'.intervening_seq_len', 'w')
	outfile_intervening_seq_NV = open('../'+data_class+'_features/'+identifier+'.intervening_seq_NV', 'w')
	outfile_entire_prot_ACC = open('../'+data_class+'_features/'+identifier+'.entire_prot_ACC', 'w')
	outfile_entire_prot_len = open('../'+data_class+'_features/'+identifier+'.entire_prot_len', 'w')

	for id1 in range(N-25):
		for id2 in range(id1+25, N):
			AA1, AA2 = prot[id1], prot[id2]
			res_pair = AA1+str(id1+1)+' '+AA2+str(id2+1)

			#residue pairs: secondary structure
			outfile_res_pairs_SS.write(res_pair+' ')
			for i in range(id1-(w-1)/2, id1+(w-1)/2+1):
				if (i >= 0) and (i < N):
					if SS_line[i] == 'H':
						outfile_res_pairs_SS.write('1 0 0 ')
					elif SS_line[i] == 'E':
						outfile_res_pairs_SS.write('0 1 0 ')
					elif SS_line[i] == 'C':
						outfile_res_pairs_SS.write('0 0 1 ')
				else:
					outfile_res_pairs_SS.write('0 0 0 ')

			for i in range(id2-(w-1)/2, id2+(w-1)/2+1):
				if (i >= 0) and (i < N):
					if SS_line[i] == 'H':
						outfile_res_pairs_SS.write('1 0 0 ')
					elif SS_line[i] == 'E':
						outfile_res_pairs_SS.write('0 1 0 ')
					elif SS_line[i] == 'C':
						outfile_res_pairs_SS.write('0 0 1 ')
				else:
					outfile_res_pairs_SS.write('0 0 0 ')
			outfile_res_pairs_SS.write('\n')


			#residue pairs: solvent accessibility
			outfile_res_pairs_ACC.write(res_pair+' ')
			for i in range(id1-(w-1)/2, id1+(w-1)/2+1):
				if (i >= 0) and (i < N):
					if ACC_line[i] == 'e':
						outfile_res_pairs_ACC.write('1 0 ')
					elif ACC_line[i] == '-':
						outfile_res_pairs_ACC.write('0 1 ')
				else:
					outfile_res_pairs_ACC.write('0 0 ')

			for i in range(id2-(w-1)/2, id2+(w-1)/2+1):
				if (i >= 0) and (i < N):
					if ACC_line[i] == 'e':
						outfile_res_pairs_ACC.write('1 0 ')
					elif ACC_line[i] == '-':
						outfile_res_pairs_ACC.write('0 1 ')
				else:
					outfile_res_pairs_ACC.write('0 0 ')
			outfile_res_pairs_ACC.write('\n')


			#residue pairs: smoothed PSSM
			outfile_res_pairs_smoothed_PSSM.write(res_pair+' ')
			for i in range(id1-(w-1)/2, id1+(w-1)/2+1):
				if (i >= 0) and (i < N):
					for j in range(20):
						outfile_res_pairs_smoothed_PSSM.write('%d ' % smoothed_PSSM_arr[i, j])
				else:
					for j in range(20):
						outfile_res_pairs_smoothed_PSSM.write('0 ')

			for i in range(id2-(w-1)/2, id2+(w-1)/2+1):
				if (i >= 0) and (i < N):
					for j in range(20):
						outfile_res_pairs_smoothed_PSSM.write('%d ' % smoothed_PSSM_arr[i, j])
				else:
					for j in range(20):
						outfile_res_pairs_smoothed_PSSM.write('0 ')
			outfile_res_pairs_smoothed_PSSM.write('\n')


			#residue pairs: coevolutionary information
			outfile_res_pairs_coevo_info.write(res_pair+' ')
			outfile_res_pairs_coevo_info.write('%f \n' % plmDCA_arr[id1, id2])


			#residue pairs: contact propensity
			outfile_res_pairs_SSCP.write(res_pair+' ')
			SS_info = SS_line[id1]+'2'+SS_line[id2]
			outfile_res_pairs_SSCP.write('%f \n' % AA_SSCP_arr[SS2id[SS_info], AA2id[AA1], AA2id[AA2]])

	
			#residue pairs: coarse contact information
			outfile_res_pairs_SSConProb.write(res_pair+' ')
			label = False
			for index in range(len(index_seqID)):
				if ((id1+1) in index_seqID[index]) and ((id2+1) in index_seqID[index]):
					outfile_res_pairs_SSConProb.write('%s %s %s \n' % (index_prob[index][0], index_prob[index][1], index_prob[index][2]))
					label = True
					break
			if not label:
				outfile_res_pairs_SSConProb.write('0 0 0 \n')


			#intervening sequences: secondary structure
			outfile_intervening_seq_SS.write(res_pair+' ')
			sep = id2-id1-1
			sep_ = sep/2
			if sep%2 == 0:
				mid = id1+sep_
				if sep_%2 == 0:
					lmid = id1+sep_/2
					rmid = mid+sep_/2
				else:
					lmid = id1+sep_/2+1
					rmid = mid+sep_/2+1
			else:
				mid = id1+sep_+1
				if sep_%2 == 0:
					lmid = id1+sep_/2+1
					rmid = mid+sep_/2
				else:
					lmid = id1+sep_/2+1
					rmid = mid+sep_/2+1

			for i in range(lmid-(cw-1)/2, lmid+(cw-1)/2+1):
				if SS_line[i] == 'H':
					outfile_intervening_seq_SS.write('1 0 0 ')
				elif SS_line[i] == 'E':
					outfile_intervening_seq_SS.write('0 1 0 ')
				elif SS_line[i] == 'C':
					outfile_intervening_seq_SS.write('0 0 1 ')
			for i in range(mid-(cw-1)/2, mid+(cw-1)/2+1):
				if SS_line[i] == 'H':
					outfile_intervening_seq_SS.write('1 0 0 ')
				elif SS_line[i] == 'E':
					outfile_intervening_seq_SS.write('0 1 0 ')
				elif SS_line[i] == 'C':
					outfile_intervening_seq_SS.write('0 0 1 ')
			for i in range(rmid-(cw-1)/2, rmid+(cw-1)/2+1):
				if SS_line[i] == 'H':
					outfile_intervening_seq_SS.write('1 0 0 ')
				elif SS_line[i] == 'E':
					outfile_intervening_seq_SS.write('0 1 0 ')
				elif SS_line[i] == 'C':
					outfile_intervening_seq_SS.write('0 0 1 ')
			outfile_intervening_seq_SS.write('\n')


			#intervening sequences: length
			outfile_intervening_seq_len.write(res_pair+' ')
			if (sep >= 24) and (sep <= 28):
				outfile_intervening_seq_len.write('1 0 0 0 0 0 0 0 0 0 \n')
			elif (sep >= 29) and (sep <= 33):
				outfile_intervening_seq_len.write('0 1 0 0 0 0 0 0 0 0 \n')
			elif (sep >= 34) and (sep <= 38):
				outfile_intervening_seq_len.write('0 0 1 0 0 0 0 0 0 0 \n')
			elif (sep >= 39) and (sep <= 43):
				outfile_intervening_seq_len.write('0 0 0 1 0 0 0 0 0 0 \n')
			elif (sep >= 44) and (sep <= 48):
				outfile_intervening_seq_len.write('0 0 0 0 1 0 0 0 0 0 \n')
			elif (sep >= 49) and (sep <= 58):
				outfile_intervening_seq_len.write('0 0 0 0 0 1 0 0 0 0 \n')
			elif (sep >= 59) and (sep <= 68):
				outfile_intervening_seq_len.write('0 0 0 0 0 0 1 0 0 0 \n')
			elif (sep >= 69) and (sep <= 78):
				outfile_intervening_seq_len.write('0 0 0 0 0 0 0 1 0 0 \n')
			elif (sep >= 79) and (sep <= 88):
				outfile_intervening_seq_len.write('0 0 0 0 0 0 0 0 1 0 \n')
			elif (sep >= 89):
				outfile_intervening_seq_len.write('0 0 0 0 0 0 0 0 0 1 \n')


			#intervening sequences: natural vector
			outfile_intervening_seq_NV.write(res_pair+' ')
			sep_frag = prot[id1+1:id2]
			nv_arr = natural_vector(sep_frag)
			for i in range(nv_arr.shape[0]):
				outfile_intervening_seq_NV.write('%f ' % nv_arr[i])
			outfile_intervening_seq_NV.write('\n')


			#entire protein: solvent accessibility
			outfile_entire_prot_ACC.write(res_pair+' ')
			outfile_entire_prot_ACC.write('%f %f \n' % (ACCPct[0], ACCPct[1]))


			#entire protein: length
			outfile_entire_prot_len.write(res_pair+' ')
			if N <= 80:
				outfile_entire_prot_len.write('1 0 0 0 \n')
			elif (N > 80) and (N <= 160):
				outfile_entire_prot_len.write('0 1 0 0 \n')
			elif (N > 160) and (N <= 240):
				outfile_entire_prot_len.write('0 0 1 0 \n')
			elif N > 240:
				outfile_entire_prot_len.write('0 0 0 1 \n')

	outfile_res_pairs_SS.close()
	outfile_res_pairs_ACC.close()
	outfile_res_pairs_smoothed_PSSM.close()
	outfile_res_pairs_coevo_info.close()
	outfile_res_pairs_SSCP.close()
	outfile_res_pairs_SSConProb.close()
	outfile_intervening_seq_SS.close()
	outfile_intervening_seq_len.close()
	outfile_intervening_seq_NV.close()
	outfile_entire_prot_ACC.close()
	outfile_entire_prot_len.close()
